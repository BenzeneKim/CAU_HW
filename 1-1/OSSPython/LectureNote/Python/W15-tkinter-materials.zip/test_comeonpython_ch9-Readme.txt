(1단계) 파일 "test_comeonpython_ch9.zip"를 디렉토리를 포함하여 압축해제한다. 
(2단계) "test_comeonpython_ch9" 디렉토리 밑에 있는 "test_comeonpython_ch9.py" 파일과 "comeonpython_src" 폴더을, 여러분의 파이썬 실행 파일 "python.exe" 위치에 복사한다. 그러면, default로 설치하였다면, "C:\Users\yourPcName\AppData\Local\Programs\Python\Python38-32\comeonpython_src" 형태가 될 것임.
(3단계) 파일 "test_comeonpython_ch9.py" 를 스크립트 모드로 실행한다

(Step-1) Unzip the file "test_comeonpython_ch9.zip" including the directory.
(Step-2) Copy the file "test_comeonpython_ch9.py" and the folder "comeonpython_src" under the directory "test_comeonpython_ch9" to the location of your Python executable. Then the fold structure should be "C:\Users\yourPcName\AppData\Local\Programs\Python\Python38-32\comeonpython_src" if you use default settings on installation
(Step-3) Run the file "test_comeonpython_ch9.py" in the script mode.